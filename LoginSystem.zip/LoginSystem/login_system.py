import random
import string

def Login(username,password):
    f = open("db.rtf","r",encoding='utf-8')
    for line in f:
        line = line.strip()
        line_list = line.split("$")
        if username == line_list[0] and password == line_list[1]:
            return True
    return False

def Register(username,password):
    if (password_check(password)):
        with open("db.rtf",'a',encoding='utf-8') as f:
            temp = "\n" + username + "$" + password
            f.write(temp)
        return True
   

def username_exist(username):
    
    with open("db.rtf","r",encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            line_list = line.split("$")
            if line_list[0] == username:
                return True
    return False

def password_check(passwd):
      
    Specialchar =['$', '@', '#', '%']
    val = True
      
    if len(passwd) < 6:
        print('length should be at least 6')
        val = False
          
    if len(passwd) > 10:
        print('length should be not be greater than 10')
        val = False
          
    if not any(char.isdigit() for char in passwd):
        print('Password should have at least one numeral')
        val = False
          
    if not any(char.isupper() for char in passwd):
        print('Password should have at least one uppercase letter')
        val = False
          
    if not any(char.islower() for char in passwd):
        print('Password should have at least one lowercase letter')
        val = False
          
    if not any(char in Specialchar for char in passwd):
        print('Password should have at least one of the symbols $@#')
        val = False
    if val:
        return val
    
def main():
    print("Welcome to taufique_login_system")
    inp = input("Enter 1. Log in; 2. Register : ")
    if inp == "1":
        user = input("Please enter username: ")
        pwd = input("Please enter your password: ")
        
        is_login = Login(user,pwd)
        if is_login:
            print("Login successful , Welcome {} !".format(user))
        else:
            print("Wrong username or Password , Login failed ! ")
    elif inp == "2":
        user = input("Please enter username: ")
        pwd = input("Please enter your password: ")
        is_exist = username_exist(user)
        if is_exist:
            print("Username already exists and cannot be registered")
            print("Available username are : ")
            name=user.lower().split()
            suname1=''.join(random.choices("ABCDEFGHIJKLMNOPQRSTUVWXYZ", k=1))\
                    +name[0]+''.join(random.choices("-_+=@[](),./#~!£$%^&*:;", k=1))+''.join(random.choices(string.digits, k=2))
            
            print(suname1)
            suname2=''.join(random.choices("ABCDEFGHIJKLMNOPQRSTUVWXYZ", k=1))\
                    +name[0]+''.join(random.choices("-_+=@[](),./#~!£$%^&*:;", k=1))+''.join(random.choices(string.digits, k=2))
            
            print(suname2)
            suname3=''.join(random.choices("ABCDEFGHIJKLMNOPQRSTUVWXYZ", k=1))\
                    +name[0]+''.join(random.choices("-_+=@[](),./#~!£$%^&*:;", k=1))+''.join(random.choices(string.digits, k=2))
            
            print(suname3)
         
        else:
            Register(user,pwd)
            
            print("~Registration successful~")
            
go = True
while go:
    main()
    p=input("Continue y/n?")
    if p == "y":
        go = True
    elif p == "n":
        go=False

    